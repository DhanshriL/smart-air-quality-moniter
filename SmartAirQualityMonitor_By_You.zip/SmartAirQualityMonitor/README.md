# Smart Air Quality Monitoring System

### Developed by: [Your Name]

## 🔧 Overview
This project is a personal IoT initiative that I built to monitor air quality in real-time using the ESP32 and the MQ135 gas sensor. It displays live data on an OLED screen, triggers alerts with an LED when air quality is poor, and publishes data to the cloud using MQTT.

## 📦 Components Used
- ESP32 Dev Module
- MQ135 Gas Sensor (CO2, NH3, smoke detection)
- SSD1306 OLED Display
- LED (for alert)
- Wi-Fi (for cloud connectivity)

## ⚙️ Features
- Real-time air quality display (PPM)
- Visual alert via LED if air quality is bad
- Data publishing to MQTT broker
- I2C OLED display for user interface

## 🛠️ Circuit Wiring
- MQ135 → GPIO34 (Analog)
- OLED (I2C) → SDA: GPIO21, SCL: GPIO22
- LED → GPIO13

## 📲 How to Use
1. Open `src/main.ino` in the Arduino IDE.
2. Replace Wi-Fi credentials in `config/wifi_credentials.h`.
3. Configure MQTT broker in `cloud/mqtt_config.h`.
4. Upload to your ESP32 board and open the Serial Monitor.

> Proudly built and documented as part of my IoT learning journey!
