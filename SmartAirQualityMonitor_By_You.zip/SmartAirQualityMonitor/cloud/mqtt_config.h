#ifndef MQTT_CONFIG_H
#define MQTT_CONFIG_H

#include <PubSubClient.h>

const char* mqtt_server = "test.mosquitto.org";
WiFiClient espClient;
PubSubClient client(espClient);

void mqtt_setup() {
  client.setServer(mqtt_server, 1883);
  while (!client.connected()) {
    if (client.connect("ESP32AirMonitor")) {
      Serial.println("MQTT connected");
    } else {
      delay(1000);
      Serial.print(".");
    }
  }
}

void sendToCloud(float ppm) {
  char payload[32];
  snprintf(payload, sizeof(payload), "ppm: %.2f", ppm);
  client.publish("home/airquality", payload);
  client.loop();
}

#endif
